import main
import card
import pygame
import os
import ctypes
import chess

x = 20
y = 0
os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (x,y)

pygame.init()

## 전역변수 세팅

break_flag = False
ESC_break = False
CardFile = ""
White_move_flag = True
S_half = 47.5
quit_flag = False

STD_INPUT_HANDLE   = -10
STD_OUTPUT_HANDLE  = -11
STD_ERROR_HANDLE   = -12
 
FOREGROUND_BLACK     = 0x00
FOREGROUND_BLUE      = 0x01 # text color contains blue.
FOREGROUND_GREEN     = 0x02 # text color contains green.
FOREGROUND_RED       = 0x04 # text color contains red.
FOREGROUND_INTENSITY = 0x08 # text color is intensified.
BACKGROUND_BLUE      = 0x10 # background color contains blue.
BACKGROUND_GREEN     = 0x20 # background color contains green.
BACKGROUND_RED       = 0x40 # background color contains red.
BACKGROUND_INTENSITY = 0x80 # background color is intensified.
 
std_out_handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
 
def set_color(color, handle=std_out_handle):
    bool = ctypes.windll.kernel32.SetConsoleTextAttribute(handle, color)
    return bool

## 각 square들의 범위 설정과 인덱싱

i = 0
for File in ["a","b","c","d","e","f","g","h"]:
    File_pos = 35 + 97*i
    j = 0
    for Rank in range(8,0,-1):
        globals()["{}{}".format(File,Rank)] = (File_pos, 8+j*97)
        j += 1
    i += 1

squares = [a8,b8,c8,d8,e8,f8,g8,h8,
    a7,b7,c7,d7,e7,f7,g7,h7,
    a6,b6,c6,d6,e6,f6,g6,h6,
    a5,b5,c5,d5,e5,f5,g5,h5,
    a4,b4,c4,d4,e4,f4,g4,h4,
    a3,b3,c3,d3,e3,f3,g3,h3,
    a2,b2,c2,d2,e2,f2,g2,h2,
    a1,b1,c1,d1,e1,f1,g1,h1]

SQUARES = ['a8','b8','c8','d8','e8','f8','g8','h8',
    'a7','b7','c7','d7','e7','f7','g7','h7',
    'a6','b6','c6','d6','e6','f6','g6','h6',
    'a5','b5','c5','d5','e5','f5','g5','h5',
    'a4','b4','c4','d4','e4','f4','g4','h4',
    'a3','b3','c3','d3','e3','f3','g3','h3',
    'a2','b2','c2','d2','e2','f2','g2','h2',
    'a1','b1','c1','d1','e1','f1','g1','h1']

## pygame 동작의 기본 요소들

size = [840,930] #보드 사이즈는 815,815 / 한칸에 97,97
screen = pygame.display.set_mode(size)

font = pygame.font.Font("NanumBarunGothic.ttf", 20)

pygame.display.set_caption("Chess Study")

background = pygame.image.load("ChessImage/chessBoard.png")
Fliped_background = pygame.image.load("ChessImage/FlipedBoard.png")

clock = pygame.time.Clock()

## 각 기물들 세팅

wP = pygame.image.load("ChessImage/wP.png")
wPsize = (62,75)
wN = pygame.image.load("ChessImage/wN.png")
wNsize = (77,88)
wB = pygame.image.load("ChessImage/wB.png")
wBsize = (67,90)
wR = pygame.image.load("ChessImage/wR.png")
wRsize = (67,82)
wQ = pygame.image.load("ChessImage/wQ.png")
wQsize = (84,86)
wK = pygame.image.load("ChessImage/wK.png")
wKsize = (84,89)
bP = pygame.image.load("ChessImage/bP.png")
bPsize = (59,74)
bN = pygame.image.load("ChessImage/bN.png")
bNsize = (80,87)
bB = pygame.image.load("ChessImage/bB.png")
bBsize = (65,89)
bR = pygame.image.load("ChessImage/bR.png")
bRsize = (66,84)
bQ = pygame.image.load("ChessImage/bQ.png")
bQsize = (89,88)
bK = pygame.image.load("ChessImage/bK.png")
bKsize = (84,89)

pieceDic = {"r":(bR,bRsize), "n":(bN,bNsize), "b":(bB,bBsize), "q":(bQ,bQsize), "k":(bK,bKsize), "p":(bP,bPsize), "P":(wP,wPsize), "R":(wR,wRsize), "N":(wN,wNsize), "B":(wB,wBsize), "Q":(wQ,wQsize), "K":(wK,wKsize)}

## 함수들 정의

def blitPiece(Square, PiecePieceSize):
    x_pos = Square[0]+S_half-PiecePieceSize[1][0]/2
    y_pos = Square[1]+S_half-PiecePieceSize[1][1]/2
    screen.blit(PiecePieceSize[0], (x_pos, y_pos))

def is_in_Square(Square, pos):
    return Square[0] <= pos[0] <= Square[0]+97 and Square[1] <= pos[1] <= Square[1]+97

def readyBoard(codeNote):
    global White_move_flag
    global squares
    global S_half
    setting = codeNote.pop(0)
    if setting != "s" :
        board = chess.Board(setting)
    else : board = chess.Board()

    starting = codeNote.pop(0)
    if starting == "b" :
        zeroMove = codeNote.pop(0)
        if zeroMove[0] == "0":
            print(zeroMove)
            board.push_san(zeroMove.split(".")[1])
        else : codeNote.insert(0,zeroMove)
        White_move_flag = False
        i=0
        for File in ["h","g","f","e","d","c","b","a"]:
            File_pos = 30 + 98*i
            j = 0
            for Rank in range(1,9):
                globals()["{}{}".format(File,Rank)] = (File_pos, 6+j*98)
                j += 1
            i += 1

        squares = [a8,b8,c8,d8,e8,f8,g8,h8,
            a7,b7,c7,d7,e7,f7,g7,h7,
            a6,b6,c6,d6,e6,f6,g6,h6,
            a5,b5,c5,d5,e5,f5,g5,h5,
            a4,b4,c4,d4,e4,f4,g4,h4,
            a3,b3,c3,d3,e3,f3,g3,h3,
            a2,b2,c2,d2,e2,f2,g2,h2,
            a1,b1,c1,d1,e1,f1,g1,h1]

        S_half = 49
    else:
        White_move_flag = True
        i = 0
        for File in ["a","b","c","d","e","f","g","h"]:
            File_pos = 35 + 97*i
            j = 0
            for Rank in range(8,0,-1):
                globals()["{}{}".format(File,Rank)] = (File_pos, 8+j*97)
                j += 1
            i += 1

        squares = [a8,b8,c8,d8,e8,f8,g8,h8,
            a7,b7,c7,d7,e7,f7,g7,h7,
            a6,b6,c6,d6,e6,f6,g6,h6,
            a5,b5,c5,d5,e5,f5,g5,h5,
            a4,b4,c4,d4,e4,f4,g4,h4,
            a3,b3,c3,d3,e3,f3,g3,h3,
            a2,b2,c2,d2,e2,f2,g2,h2,
            a1,b1,c1,d1,e1,f1,g1,h1]

        S_half = 48.5

    return board

# 텍스트 색상 함수
def printRed(text):
    set_color(12)
    print(text)
    set_color(15)

def printGreen(text):
    set_color(2)
    print(text)
    set_color(15)

def printYellow(text):
    set_color(14)
    print(text)
    set_color(15)

def printBlue(text):
    set_color(1)
    print(text)
    set_color(15)

def printTitle(text):
    set_color(16*7)
    print(text)
    set_color(15)

def Study(cd:card.Card):
  codeNote = cd.Read()
  running = True

  click_flag = False
  moveNote = []
  MoveNote = ""
  incollectmove_count = 0
  GameEnd = False
  Title_flag = True
  SideLine_flag = False
  key_flag = False
  SideLineEnd_flag = False
  boardSaveFen = []
  promotion_q = False
  promotion_n = False
  wrongAnswer = 0
  board = readyBoard(codeNote)
  while running :
      
    clock.tick(10)
    screen.fill((77,76,72))
    if White_move_flag:
      screen.blit(background, (0,0))
    else :
      screen.blit(Fliped_background, (0,0))

    # 상호작용할 event들

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
            quit_flag=True
            break
        elif event.type == pygame.MOUSEBUTTONDOWN:
            click_flag = True
            click_pos = pygame.mouse.get_pos()
        elif event.type == pygame.KEYDOWN:
            # pressed = pygame.key.get_pressed()
            # buttons = [pygame.key.name(k) for k, v in enumerate(pressed) if v]    # 첫 입력값을 buttons[0]로 취함
            if event.key == pygame.K_RIGHT:
                cd.Correct()
                running = False
            elif event.key == pygame.K_UP:
                cd.Perfect()
                running = False
            elif event.key == pygame.K_DOWN:
                cd.Withhold()
                running = False
            elif event.key == pygame.K_LEFT:
                cd.Incorrect()
                running = False
            elif event.key == pygame.K_SPACE :
                key_flag = True
            elif event.key == pygame.K_q :
                promotion_q = True
            elif event.key == pygame.K_n :
                promotion_n = True
            elif event.key == pygame.K_ESCAPE:
                running = False
                quit_flag = True
                break

    # 보드 상황 받아서 배치

    if SideLineEnd_flag and not key_flag :
        continue
    elif SideLineEnd_flag and key_flag :
        key_flag = False
        SideLineEnd_flag = False

    if codeNote and codeNote[0][0] == "[" :
        printYellow(codeNote.pop(0))
        boardSaveFen.append(board.fen())
        SideLine_flag = True

    boardList = str(board).split()

    for sq in range(64):
        if boardList[sq] != "." :
            blitPiece(squares[sq],pieceDic[boardList[sq]])
    
    if SideLine_flag and codeNote and codeNote[0][0] == "]" :
        printYellow(codeNote.pop(0))
        board = chess.Board(boardSaveFen.pop())
        SideLineEnd_flag = True
        if not boardSaveFen :
            SideLine_flag = False
        pygame.display.flip()
        continue

    # 주석 처리

    if codeNote and codeNote[0][0] == "#" :
        Text = codeNote.pop(0)[1:]
        printGreen(Text)

    if codeNote and codeNote[0][0] == "!" :
        Text = codeNote.pop(0)[1:]
        printRed(Text)

    if codeNote and codeNote[0][0] == "@" :
        Text = codeNote.pop(0)[1:]
        printYellow(Text)
    
    if codeNote and codeNote[0][0] == "&" :
        Text = codeNote.pop(0)[1:]
        if Title_flag :
            printTitle(Text)
            Title_flag = False
        else : 
            print(Text)

    # 엔딩 처리

    if GameEnd :
        printRed("Total Wong Answer : %.1f" %(wrongAnswer))
        printYellow("## Game End ##")
        GameEnd = False
        pygame.display.flip()
        continue

    # 기물 이동을 위한 마우스 클릭

    if click_flag :
        for sq in range(64): 
            if is_in_Square(squares[sq], click_pos):
                moveNote.append(SQUARES[sq])
                if len(moveNote) == 2 :
                    if moveNote[0] == moveNote[1]:
                        moveNote.clear()
                        continue
                    MoveNote = "".join(moveNote)
                    if promotion_q:
                        MoveNote +="q"
                        promotion_q = False
                    if promotion_n:
                        MoveNote +="n"
                        promotion_n = False
                    moveNote.clear()
                    if chess.Move.from_uci(MoveNote) in board.legal_moves :
                        LastMoveSet = codeNote.pop(0)
                        Moves = LastMoveSet.split(".")[1].split()
                        Move1 = Moves[0].replace("?","")
                        Move1 = Move1.replace("!","")
                        if chess.Move.from_uci(MoveNote) == board.parse_san(Move1) :
                            board.push_uci(MoveNote)
                            incollectmove_count = 0
                            print(LastMoveSet)
                            if len(Moves) > 1 :
                                if Moves[1] == "1-0" :
                                    printYellow("흑이 기권")
                                    GameEnd = True
                                elif Moves[1] == "0-1" :
                                    printYellow("백이 기권")
                                    GameEnd = True
                                else :
                                    Move2 = Moves[1].replace("?","")
                                    Move2 = Move2.replace("!","")
                                    board.push_san(Move2)
                            elif board.is_checkmate() :
                                    printYellow("mate!")
                                    if not SideLine_flag :
                                        GameEnd = True
                            elif not SideLine_flag :
                                GameEnd = True
                        else : 
                            codeNote.insert(0,LastMoveSet)
                            incollectmove_count += 1
                            wrongAnswer += 1
                            printRed("incorrect move!")
                            printBlue("-Wrong Answer %.1f" %(wrongAnswer))
                            if incollectmove_count >= 2 and incollectmove_count <= 4 :
                                print("힌트:"+LastMoveSet.split(".")[1][0])
                            elif incollectmove_count > 4 :
                                print("답:"+LastMoveSet)
                    else : 
                        printRed("illegal move!")
                        incollectmove_count += 1
                        wrongAnswer += 0.1
                    MoveNote = ""
                click_flag = False

    pygame.display.flip()

def NewStudy(cd:card.Card):
  codeNote = cd.NewRead()
  running = True

  click_flag = False
  moveNote = []
  MoveNote = ""
  incollectmove_count = 0
  GameEnd = False
  Title_flag = True
  SideLine_flag = False
  key_flag = False
  SideLineEnd_flag = False
  boardSaveFen = []
  promotion_q = False
  promotion_n = False
  wrongAnswer = 0
  board = readyBoard(codeNote)
  while running :
      
    clock.tick(10)
    screen.fill((77,76,72))
    if White_move_flag:
      screen.blit(background, (0,0))
    else :
      screen.blit(Fliped_background, (0,0))

    # 상호작용할 event들

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
            quit_flag = True
            break
        elif event.type == pygame.MOUSEBUTTONDOWN:
            click_flag = True
            click_pos = pygame.mouse.get_pos()
        elif event.type == pygame.KEYDOWN:
            # pressed = pygame.key.get_pressed()
            # buttons = [pygame.key.name(k) for k, v in enumerate(pressed) if v]    # 첫 입력값을 buttons[0]로 취함
            if event.key == pygame.K_RIGHT:
                cd.Correct()
                running = False
            elif event.key == pygame.K_UP:
                cd.Perfect()
                running = False
            elif event.key == pygame.K_DOWN:
                cd.Withhold()
                running = False
            elif event.key == pygame.K_LEFT:
                cd.Incorrect()
                running = False
            elif event.key == pygame.K_SPACE :
                key_flag = True
            elif event.key == pygame.K_q :
                promotion_q = True
            elif event.key == pygame.K_n :
                promotion_n = True
            elif event.key == pygame.K_ESCAPE:
                running = False
                quit_flag = True
                break

    # 보드 상황 받아서 배치

    if SideLineEnd_flag and not key_flag :
        continue
    elif SideLineEnd_flag and key_flag :
        key_flag = False
        SideLineEnd_flag = False

    if codeNote and codeNote[0][0] == "[" :
        printYellow(codeNote.pop(0))
        boardSaveFen.append(board.fen())
        SideLine_flag = True

    boardList = str(board).split()

    for sq in range(64):
        if boardList[sq] != "." :
            blitPiece(squares[sq],pieceDic[boardList[sq]])
    
    if SideLine_flag and codeNote and codeNote[0][0] == "]" :
        printYellow(codeNote.pop(0))
        board = chess.Board(boardSaveFen.pop())
        SideLineEnd_flag = True
        if not boardSaveFen :
            SideLine_flag = False
        pygame.display.flip()
        continue

    # 주석 처리

    if codeNote and codeNote[0][0] == "#" :
        Text = codeNote.pop(0)[1:]
        printGreen(Text)

    if codeNote and codeNote[0][0] == "!" :
        Text = codeNote.pop(0)[1:]
        printRed(Text)

    if codeNote and codeNote[0][0] == "@" :
        Text = codeNote.pop(0)[1:]
        printYellow(Text)
    
    if codeNote and codeNote[0][0] == "&" :
        Text = codeNote.pop(0)[1:]
        if Title_flag :
            printTitle(Text)
            Title_flag = False
        else : 
            print(Text)

    # 엔딩 처리

    if GameEnd :
        printRed("Total Wong Answer : %.1f" %(wrongAnswer))
        printYellow("## Game End ##")
        GameEnd = False
        pygame.display.flip()
        continue

    # 기물 이동을 위한 마우스 클릭

    if click_flag :
        for sq in range(64): 
            if is_in_Square(squares[sq], click_pos):
                moveNote.append(SQUARES[sq])
                if len(moveNote) == 2 :
                    if moveNote[0] == moveNote[1]:
                        moveNote.clear()
                        continue
                    MoveNote = "".join(moveNote)
                    if promotion_q:
                        MoveNote +="q"
                        promotion_q = False
                    if promotion_n:
                        MoveNote +="n"
                        promotion_n = False
                    moveNote.clear()
                    if chess.Move.from_uci(MoveNote) in board.legal_moves :
                        LastMoveSet = codeNote.pop(0)
                        Moves = LastMoveSet.split(".")[1].split()
                        Move1 = Moves[0].replace("?","")
                        Move1 = Move1.replace("!","")
                        if chess.Move.from_uci(MoveNote) == board.parse_san(Move1) :
                            board.push_uci(MoveNote)
                            incollectmove_count = 0
                            print(LastMoveSet)
                            if len(Moves) > 1 :
                                if Moves[1] == "1-0" :
                                    printYellow("흑이 기권")
                                    GameEnd = True
                                elif Moves[1] == "0-1" :
                                    printYellow("백이 기권")
                                    GameEnd = True
                                else :
                                    Move2 = Moves[1].replace("?","")
                                    Move2 = Move2.replace("!","")
                                    board.push_san(Move2)
                            elif board.is_checkmate() :
                                    printYellow("mate!")
                                    if not SideLine_flag :
                                        GameEnd = True
                            elif not SideLine_flag :
                                GameEnd = True
                        else : 
                            codeNote.insert(0,LastMoveSet)
                            incollectmove_count += 1
                            wrongAnswer += 1
                            printRed("incorrect move!")
                            printBlue("-Wrong Answer %.1f" %(wrongAnswer))
                            if incollectmove_count >= 2 and incollectmove_count <= 4 :
                                print("힌트:"+LastMoveSet.split(".")[1][0])
                            elif incollectmove_count > 4 :
                                print("답:"+LastMoveSet)
                    else : 
                        printRed("illegal move!")
                        incollectmove_count += 1
                        wrongAnswer += 0.1
                    MoveNote = ""
                click_flag = False

    pygame.display.flip()
