import main
import card
import pygame
from sys import getsizeof
import os

x = 20
y = 30
os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (x,y)

pygame.init()

size = [800,780] 
screen = pygame.display.set_mode(size)
font = pygame.font.Font("NanumBarunGothic.ttf", 20)
pygame.display.set_caption("{}".format(main.BOX_NAME))
clock = pygame.time.Clock()

def PrintText(msg, ypos = 50, color = "WHITE"):
  text_surface = font.render(msg, True, pygame.Color(color), None)
  screen.blit(text_surface, (270-(getsizeof(msg)), ypos))

def PrintQuestion(page:list):
  for i, ypos in enumerate(range(370 - len(page)*14, 370 + len(page)*14, 28)):
    PrintText(page[i], ypos)

def PrintAnswer(page:list, line:int):
  i = 0
  ypos = 370 - line*14
  while line != 0:
    if len(page)<=i:
      break
    if page[i][0] == "#":
      PrintText(page[i][1:], ypos, "GREEN")
    else:
      line -= 1
      PrintText(page[i], ypos)
    ypos += 28
    i += 1
  while len(page)>i and page[i][0] == "#":
    PrintText(page[i][1:], ypos, "GREEN")
    i += 1
    ypos += 28


def Study(cd:card.Card):
  note = cd.Read()
  running = True

  flip_flag = False
  first_flip_flag = True
  sep_index = note.index("@")
  question = note[:sep_index]
  answer = note[sep_index+1:]
  
  ans_line = -1

  while running:
    clock.tick(10)
    screen.fill((30,30,30))

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False
      elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT:
          cd.Correct()
          running = False
        elif event.key == pygame.K_UP:
          cd.Perfect()
          running = False
        elif event.key == pygame.K_DOWN:
          cd.Withhold()
          running = False
        elif event.key == pygame.K_LEFT:
          cd.Incorrect()
          running = False
        elif event.key == pygame.K_SPACE:
          ans_line += 1
          flip_flag = True
        elif event.key == pygame.K_BACKSPACE:
          ans_line -= 1
          
    if not flip_flag:
      PrintQuestion(question)
    else:
      if first_flip_flag:
        print("--"*len(question[0]))
        print("\n".join(question))
        first_flip_flag = False
      PrintAnswer(answer, ans_line)
      
    pygame.display.flip()

def NewStudy(cd:card.Card):
  note = cd.NewRead()
  running = True

  flip_flag = False
  first_flip_flag = True
  sep_index = note.index("@")
  question = note[:sep_index]
  answer = note[sep_index+1:]
  
  ans_line = -1

  while running:
    clock.tick(10)
    screen.fill((30,30,30))

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False
      elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT:
          cd.Correct()
          running = False
        elif event.key == pygame.K_UP:
          cd.Perfect()
          running = False
        elif event.key == pygame.K_DOWN:
          cd.Withhold()
          running = False
        elif event.key == pygame.K_LEFT:
          cd.Incorrect()
          running = False
        elif event.key == pygame.K_SPACE:
          ans_line += 1
          flip_flag = True
        elif event.key == pygame.K_BACKSPACE:
          ans_line -= 1
          
    if not flip_flag:
      PrintQuestion(question)
    else:
      if first_flip_flag:
        print("--"*len(question[0]))
        print("\n".join(question))
        first_flip_flag = False
      PrintAnswer(answer, ans_line)
      
    pygame.display.flip()