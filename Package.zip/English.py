import main
import card
import pygame
from sys import getsizeof
import os

x = 20
y = 60
os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (x,y)

quit_flag = [False]

pygame.init()

size = [600,400] 
screen = pygame.display.set_mode(size)
font = pygame.font.Font("NanumBarunGothic.ttf", 30)
pygame.display.set_caption("{}".format(main.BOX_NAME))
clock = pygame.time.Clock()

def PrintText(msg, ypos = 50, color = "WHITE"):
  text_surface = font.render(msg, True, pygame.Color(color), None)
  if msg and '가' <= msg[0] <= '힣':
    char_size = 10
  else:
    char_size = 6
  screen.blit(text_surface, (270-(len(msg)*char_size), ypos))

def Print(page:list):
  for i, ypos in enumerate(range(170 - len(page)*19, 170 + len(page)*19, 38)):
    if page[i] and page[i][0] == '#':
      PrintText(page[i][1:], ypos, "GREEN")
    else:
      PrintText(page[i], ypos)

def Study(cd:card.Card):
  note = cd.Read()
  running = True

  flip_flag = True
  sep_index = note.index("@")
  question = note[:sep_index]
  answer = note[sep_index+1:]

  while running:
    clock.tick(10)
    screen.fill((30,30,30))

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False
        quit_flag[0] = True
      elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT:
          cd.Correct()
          running = False
        elif event.key == pygame.K_UP:
          cd.Perfect()
          running = False
        elif event.key == pygame.K_DOWN:
          cd.Withhold()
          running = False
        elif event.key == pygame.K_LEFT:
          cd.Incorrect()
          running = False
        elif event.key == pygame.K_SPACE:
          flip_flag = not flip_flag
        elif event.key == pygame.K_ESCAPE:
          running = False
          quit_flag[0] = True
          
    if flip_flag:
      Print(question)
    else:
      Print(answer)
    
    pygame.display.flip()

def NewStudy(cd:card.Card):
  note = cd.NewRead()
  running = True

  flip_flag = True
  sep_index = note.index("@")
  question = note[:sep_index]
  answer = note[sep_index+1:]

  while running:
    clock.tick(10)
    screen.fill((30,30,30))

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False
        quit_flag[0] = True
      elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT:
          cd.Correct()
          running = False
        elif event.key == pygame.K_UP:
          cd.Perfect()
          running = False
        elif event.key == pygame.K_DOWN:
          cd.Withhold()
          running = False
        elif event.key == pygame.K_LEFT:
          cd.Incorrect()
          running = False
        elif event.key == pygame.K_SPACE:
          flip_flag = not flip_flag
        elif event.key == pygame.K_ESCAPE:
          running = False
          quit_flag[0] = True
      
    if flip_flag:
      Print(question)
    else:
      Print(answer)
    
    pygame.display.flip()
