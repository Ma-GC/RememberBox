import main
from time import time
from shutil import move

SEC_DAY = 86400

class Card:
  def __init__(self, name, time=0, period=0):
    self.name = name
    self.time = time
    self.period = period
  
  def SetTime(self):
    self.time = int(time())
  
  def CheckGoal(self):
    if self.period > main.GOAL * SEC_DAY:
      move("list/"+self.name, "complete/"+self.name)
      self.period = 0
  
  def Correct(self):
    self.SetTime()
    if self.period == 0:
      self.period = main.FIRST_CORRECT * SEC_DAY
      move("C:/Users/user/Desktop/{}_stepA/{}".format(main.BOX_NAME, self.name), "list/"+self.name)
    else:
      self.period = int(self.period * main.CORRECT)
      self.CheckGoal()

  def Perfect(self):
    self.SetTime()
    if self.period == 0:
      self.period = main.FIRST_PERFECT * SEC_DAY
      move("C:/Users/user/Desktop/{}_stepA/{}".format(main.BOX_NAME, self.name), "list/"+self.name)
    else:
      self.period = int(self.period * main.PERRECT)
      self.CheckGoal()

  def Incorrect(self):
    if self.period == 0:
      return
    self.SetTime()
    new_period = int(self.period * main.INCORRECT)
    if new_period < main.INCORRECT_MIN * SEC_DAY :
      self.period = main.INCORRECT_MIN * SEC_DAY
    elif new_period > main.INCORRECT_MAX * SEC_DAY :
      self.period = main.INCORRECT_MAX * SEC_DAY
    else:
      self.period = new_period
  
  def Withhold(self):
    if self.period == 0:
      return
    self.SetTime()
    self.period = int(self.period * main.WITHHOLD)

  def Read(self):
    card_file = open("list/" + self.name, "r", encoding="UTF-8")
    card = card_file.read().splitlines()
    card_file.close()
    return card
  
  def NewRead(self):
    card_file = open("C:/Users/user/Desktop/{}_stepA/{}".format(main.BOX_NAME, self.name), "r", encoding="UTF-8")
    card = card_file.read().splitlines()
    card_file.close()
    return card
