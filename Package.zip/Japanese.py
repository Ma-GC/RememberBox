import main
import card
import pygame
from sys import getsizeof
import os

x = 20
y = 60
os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (x,y)

pygame.init()

size = [600,400] 
screen = pygame.display.set_mode(size)
kfont = pygame.font.Font("Kyobo Handwriting 2019.ttf", 35)
jfont = pygame.font.Font("UDDigiKyokashoN-R.ttc", 32)
pygame.display.set_caption("{}".format(main.BOX_NAME))
clock = pygame.time.Clock()

quit_flag = [False]

def PrintText(msg, ypos = 50, color = "WHITE"):
  if msg and '가' <= msg[len(msg)-2] <= '힣':
    text_surface = kfont.render(msg, True, pygame.Color(color), None)
  elif msg and '가' <= msg[-1] <= '힣':
    text_surface = kfont.render(msg, True, pygame.Color(color), None)
  else:
    text_surface = jfont.render(msg, True, pygame.Color(color), None)
  screen.blit(text_surface, (270-(len(msg)*12), ypos))

def Print(page:list):
  for i, ypos in enumerate(range(170 - len(page)*19, 170 + len(page)*19, 38)):
    if page[i] and page[i][0] == '#':
      PrintText(page[i][1:], ypos, "GREEN")
    else:
      PrintText(page[i], ypos)

def Study(cd:card.Card):
  note = cd.Read()
  running = True

  flip_flag = True
  sep_index = note.index("@")
  question = note[:sep_index]
  answer = note[sep_index+1:]

  while running:
    clock.tick(10)
    screen.fill((30,30,30))

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False
        quit_flag[0] = True
      elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT:
          cd.Correct()
          running = False
        elif event.key == pygame.K_UP:
          cd.Perfect()
          running = False
        elif event.key == pygame.K_DOWN:
          cd.Withhold()
          running = False
        elif event.key == pygame.K_LEFT:
          cd.Incorrect()
          running = False
        elif event.key == pygame.K_SPACE:
          flip_flag = not flip_flag
        elif event.key == pygame.K_ESCAPE:
          running = False
          quit_flag[0] = True
      
    if flip_flag:
      Print(question)
    else:
      Print(answer)
    
    pygame.display.flip()

def NewStudy(cd:card.Card):
  note = cd.NewRead()
  running = True

  flip_flag = True
  sep_index = note.index("@")
  question = note[:sep_index]
  answer = note[sep_index+1:]

  while running:
    clock.tick(10)
    screen.fill((30,30,30))

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False
        quit_flag[0] = True
      elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT:
          cd.Correct()
          running = False
        elif event.key == pygame.K_UP:
          cd.Perfect()
          running = False
        elif event.key == pygame.K_DOWN:
          cd.Withhold()
          running = False
        elif event.key == pygame.K_LEFT:
          cd.Incorrect()
          running = False
        elif event.key == pygame.K_SPACE:
          flip_flag = not flip_flag
        elif event.key == pygame.K_ESCAPE:
          running = False
          quit_flag[0] = True
      
    if flip_flag:
      Print(question)
    else:
      Print(answer)
    
    pygame.display.flip()
