print("불러오는 중...")
import collections
import os
from time import time
import Tool 
import card

#기본 상수 값
SEC_DAY = 86400

#상자 이름 및 바탕화면 경로 얻어내기
current_path = os.getcwd().split("\\")
BOX_NAME = current_path.pop()
current_path.pop()
DESKTOP_PATH = "/".join(current_path) + "/Desktop"
del current_path

#Setting정보 불러와서 변수에 설정
setting_file = open("Setting.txt", "r")
setting_info = collections.deque(setting_file.read().splitlines())
setting_file.close()

NUM_STEP_A = int(setting_info.popleft().split(":")[1])
FIRST_CORRECT = int(setting_info.popleft().split(":")[1])
FIRST_PERFECT = int(setting_info.popleft().split(":")[1])
INCORRECT = float(setting_info.popleft().split(":")[1])
WITHHOLD = float(setting_info.popleft().split(":")[1])
CORRECT = float(setting_info.popleft().split(":")[1])
PERRECT = float(setting_info.popleft().split(":")[1])
GOAL = int(setting_info.popleft().split(":")[1])
INCORRECT_MIN = int(setting_info.popleft().split(":")[1])
INCORRECT_MAX = int(setting_info.popleft().split(":")[1])

del setting_info

if __name__ == "__main__":
  try:
    os.system("cls")
    while True:
      #파일 이름과 시간 정보를 키와 값으로 갖는 사전 : 값 = (최근 복습 시간, 다음 복습까지의 기간)
      data_file = open("Data.txt", "r", encoding="UTF-8")
      data_info = data_file.read().splitlines()
      data_file.close()

      file_name_time = {}
      for file_time_info in data_info:
        
        name_time = file_time_info.split(":")
        file_name_time[name_time[0]] = (int(name_time[1].split("_")[0]), int(name_time[1].split("_")[1]))

      del data_info

      #현재 시간을 고정 시킴
      STUDY_TIME = int(time())
      #복습 해야 할 카드 목록 얻어내고
      StudyList = [] 
      for name in file_name_time:
        if (file_name_time[name][0] + file_name_time[name][1]) < STUDY_TIME:
          StudyList.append(name)

      def SortByTime(name):
        return file_name_time[name][0] + file_name_time[name][1] - STUDY_TIME

      #진행상황도 모두 알아냄
      StudyList.sort(key=SortByTime)
      ProcessInfo = {"{}일 이하".format(int(GOAL/18)):0,
                    "{}일 이하".format(int(GOAL/9)):0, 
                    "{}일 이하".format(int(GOAL/6)):0,
                    "{}일 이하".format(int(GOAL/3)):0,
                    "{}일 이하".format(int(GOAL/2)):0,
                    "목표달성":len(os.listdir("complete"))}
      for name in file_name_time:
        StudyDay = file_name_time[name][1]//SEC_DAY
        if StudyDay <= int(GOAL/18):
          ProcessInfo["{}일 이하".format(int(GOAL/18))] += 1
        elif StudyDay <= int(GOAL/9):
          ProcessInfo[ "{}일 이하".format(int(GOAL/9)) ] += 1
        elif StudyDay <= int(GOAL/6):
          ProcessInfo[ "{}일 이하".format(int(GOAL/6)) ] += 1
        elif StudyDay <= int(GOAL/3):
          ProcessInfo[ "{}일 이하".format(int(GOAL/3)) ] += 1
        elif StudyDay <= int(GOAL/2):
          ProcessInfo[ "{}일 이하".format(int(GOAL/2)) ] += 1

      #로딩 종료

      print(ProcessInfo)
      print("복습할 카드 수 : {}".format(len(StudyList)))
      if StudyList:
        yn = input("복습 하시겠습니까?(y/n) : ")

      if yn == "y":
        for name in StudyList:
          note = card.Card(name, int(file_name_time[name][0]), int(file_name_time[name][1]))
          print("--"*len(name))
          incor_period = note.period * INCORRECT
          if incor_period < INCORRECT_MIN*SEC_DAY:
            incor_period = INCORRECT_MIN
          elif incor_period > INCORRECT_MAX*SEC_DAY:
            incor_period = INCORRECT_MAX
          else:
            incor_period = incor_period/SEC_DAY
          print("<{:.1f}<{:.1f}<{:.1f}>{:.1f}>{:.1f}>".format(incor_period,
                                          (note.period*WITHHOLD)/SEC_DAY,
                                          note.period/SEC_DAY,
                                          (note.period*CORRECT)/SEC_DAY,
                                          (note.period*PERRECT)/SEC_DAY))
          print("--"*len(name))
          Tool.Study(note)
          if note.period == 0:
            file_name_time.pop(note.name)
          else:  
            file_name_time[note.name] = (note.time, note.period)
          
          if Tool.quit_flag[0]:
            Tool.quit_flag[0] = False
            break

        del StudyList
        
        data_write = []
        for name in file_name_time:
          data_write.append(name+":"+str(file_name_time[name][0])+"_"+str(file_name_time[name][1]))
        data_file = open("Data.txt", "w", encoding="UTF-8")
        data_file.write("\n".join(data_write))
        data_file.write("\n")
        data_file.close()
        del data_write
      else:
        new_list = os.listdir("{}/{}_stepA".format(DESKTOP_PATH,BOX_NAME))
        nyn = input("새 카드 수 : {}\n새 카드를 공부할까요?(y/n) : ".format(len(os.listdir("{}/{}_stepA".format(DESKTOP_PATH,BOX_NAME)))))
        
        if nyn == "y":
          add_name_time = []
          for name in new_list:
            note = card.Card(name)
            Tool.NewStudy(note)
            if note.period != 0:
              print("pass")
              add_name_time.append(name+":"+str(note.time)+"_"+str(note.period))
            else:
              print("-")
            if Tool.quit_flag[0]:
              Tool.quit_flag[0] = False
              break
          print("pass::{}개".format(len(add_name_time)))

          if add_name_time:
            data_file = open("Data.txt", "a", encoding="UTF-8")
            data_file.write("\n".join(add_name_time))
            data_file.write("\n")
            data_file.close()
          del add_name_time

        else:
          qyn = input("종료하시겠습니까?(y/n) : ")
          if qyn == "y":
            break
  except Exception as exp:
    data_write = []
    for name in file_name_time:
      data_write.append(name+":"+str(file_name_time[name][0])+"_"+str(file_name_time[name][1]))
    data_file = open("Data.txt", "w", encoding="UTF-8")
    data_file.write("\n".join(data_write))
    data_file.write("\n")
    data_file.close()
    del data_write
    
    if add_name_time:
      data_file = open("Data.txt", "a", encoding="UTF-8")
      data_file.write("\n".join(add_name_time))
      data_file.write("\n")
      data_file.close()
      del add_name_time
      
    print("오류 발생!")
    print(exp)
    os.system("pause")
