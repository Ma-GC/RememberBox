import os

wfn = "write.txt"   # write file name 작성한 파일 이름
wc = open(wfn, "r", encoding="UTF-8")
li = wc.read().splitlines()
wc.close()

for card in li:
  card = card.replace("/", "\n")
  print(card)
  card = card.replace("@", "\n@\n")
  print(card)
  file_name = card.split("\n")[0]
  file_name = file_name.replace("?","")
  if file_name[-1] == ".":
    file_name = file_name[:-1]
  mk_card = open("./maked/"+file_name+".txt", "w", encoding="UTF-8")
  mk_card.write(card)
  mk_card.close()
